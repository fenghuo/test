
public class MasterInfo {
	public static String url = "http://127.0.0.1:1918/handle";
}
