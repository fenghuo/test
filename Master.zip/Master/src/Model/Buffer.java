package Model;

public class Buffer {
	
	public static String checkBuf = null;
	
}
