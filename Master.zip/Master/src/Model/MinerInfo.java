package Model;

public class MinerInfo {
	public static int NUMBER = 1;
	
	public static String urls[] = new String[]{
		"http://127.0.0.1:8080/recv",
	};
}
